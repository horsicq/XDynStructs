struct _DBGKD_READ_MEMORY64// Size=0x10
{
    unsigned long long TargetBaseAddress;// Offset=0x0 Size=0x8
    unsigned long TransferCount;// Offset=0x8 Size=0x4
    unsigned long ActualBytesRead;// Offset=0xc Size=0x4
};